---
agent: feature-orchestrator-plugin:feature-orchestrator.agent
description: "Configure the Feature Orchestrator for this project (first-time setup)"
---

# Setup — Feature Orchestrator Configuration

Guide the user through setting up `.github/orchestrator-config.json` for this project.

**Check first**: Does `.github/orchestrator-config.json` already exist?
- If yes, read it and ask: "Configuration already exists. Would you like to update it or start fresh?"
- If no, proceed with setup.

## Pre-Discovery (before the setup flow)

**Before showing any setup questions**, gather context that helps pre-fill answers.
Tell the user what you're doing:
> "Let me discover your project structure first — I'll check git remotes, build files,
> and project metadata so I can pre-fill the setup questions for you."

Run these discovery steps:

1. **Project name & description hints** — Read these files (if they exist) to infer a name/description:
   - `README.md` — look for the first `#` heading and first paragraph
   - `package.json` — check `name` and `description` fields
   - `build.gradle` / `settings.gradle` — check `rootProject.name`
   - `pom.xml` — check `<name>` and `<description>`
   - `Cargo.toml` — check `[package]` name
   - Workspace directory name as fallback

2. **Repository discovery** — Find distinct git remotes (as described in Step 3a)

3. **Module discovery** — Find logical modules (as described in Step 3b)

4. **ADO hints from repo URLs** — If any repo is ADO-hosted, parse the org and project
   from the URL for pre-filling Step 5

5. **Tool availability** — Check `node --version`, `gh --version`, `az --version`

Store all discovered data internally, then begin the setup flow with pre-filled suggestions.

## Setup Flow

Use `askQuestion` for each step. Batch related questions when possible.
Output each step heading as a **separate markdown line** before the question UI.

**⚠️ askQuestion rule**: When using `allowFreeformInput: true`, do NOT also include an
option like "Enter a different answer" or "Type custom value" — the `allowFreeformInput`
already adds a freeform text field automatically. Adding an explicit option for it creates
a confusing duplicate where one is clickable-but-not-typeable and the other is typeable.

---

### Step 1: Verify Prerequisites

Tell the user:
> "Let me check that the required tools are installed before we begin. This ensures
> we don't go through the full setup only to find out something is missing."

Check tool availability (from Pre-Discovery results):
```powershell
node --version     # Node.js (for state-utils) — REQUIRED
gh --version       # GitHub CLI — only needed if any repos are on GitHub
az --version       # Azure CLI — only needed if using ADO work items
```

**Node.js** is always required (for state tracking). If missing:
> "Node.js is required for the orchestrator. Install:
> `winget install OpenJS.NodeJS.LTS` (Windows) or `brew install node` (macOS) or https://nodejs.org"
**This is a blocker** — do not proceed until Node.js is available.

**GitHub CLI** — only check if there are GitHub-hosted repos (from Pre-Discovery):
- If installed → note it, proceed
- If NOT installed and there ARE GitHub repos → offer to install:
  - Windows: `winget install --id GitHub.cli -e`
  - macOS: `brew install gh`
  - If user declines: warn that **dispatch and PR monitoring will not work** for GitHub repos.
- If NOT installed and there are NO GitHub repos → skip

**Azure CLI** — only check if there is ADO configuration needed:
- If installed → note it, proceed
- If not installed → note it's optional:
  > "Azure CLI is optional but recommended for live PBI status updates.
  > Install: `winget install Microsoft.AzureCLI` (Windows) or `brew install azure-cli` (macOS)"

Present a quick summary:
```markdown
### Prerequisites
- **Node.js**: v24.14.0 ✅
- **GitHub CLI**: v2.87.3 ✅
- **Azure CLI**: v2.82.0 ✅ (or ⚠️ Not installed — optional)
```

---

### Step 2: Project Info

Tell the user:
> "I need some basic info about your project. This is used in work item titles,
> design spec headers, and dashboard labels."

**Always provide a recommended name and description** from Pre-Discovery. Present them
on their **own lines** — do NOT concatenate the step header with the question text.

Use the best source available:
- README.md first heading → project name
- README.md first paragraph → description
- `package.json` name/description
- `build.gradle` rootProject.name
- Directory name as last resort

```
askQuestion({
  questions: [
    {
      header: "Project Name",
      question: "What's the short name for this project?",
      options: [
        { label: "<discovered-name>", description: "From README / build config", recommended: true }
      ],
      allowFreeformInput: true
    },
    {
      header: "Project Description",
      question: "One-line description of the project:",
      options: [
        { label: "<discovered-description>", description: "From README / build config", recommended: true }
      ],
      allowFreeformInput: true
    }
  ]
})
```

---

### Step 3: Repository & Module Mapping

Tell the user:
> "I've analyzed your workspace and detected your repositories and modules. Let me
> show you what I found — you'll just need to confirm it's correct."

This step presents the results from **Pre-Discovery** (repos and modules were already
detected before Step 1). No additional discovery commands need to run here.

The two concepts:
- **Repositories**: Where code lives (GitHub or ADO (Azure DevOps)). Needed for dispatch, PRs, and monitoring.
- **Modules**: Logical components within a repo. A single repo can have multiple modules
  (e.g., `core/`, `api/`, `web/` in a monorepo). Modules are used to route work items to
  the right part of the right repo.

#### Step 3a: Discover Repositories

Find all distinct git remotes in the workspace:

1. Check if the workspace root has subdirectories with their own `.git` (submodules/sub-repos):
   ```powershell
   # For each top-level directory, check for its own git remote
   Get-ChildItem -Directory | ForEach-Object { git -C $_.Name remote get-url origin 2>$null }
   ```
2. Also check the workspace root's own remote: `git remote get-url origin`
3. Deduplicate — multiple directories may share the same remote (same repo).

**Parse each remote URL into a slug:**
- GitHub: `https://github.com/org/repo.git` → `org/repo`
- GitHub SSH: `git@github.com:org/repo.git` → `org/repo`
- ADO: `https://org@dev.azure.com/org/project/_git/repo` → `org/project/repo`
- ADO: `https://org.visualstudio.com/.../project/_git/repo` → `org/project/repo`
  (Both `dev.azure.com` and `visualstudio.com` URLs are ADO — treat them identically.
  **Do NOT label either as "legacy" or "new"** when presenting to the user — just show `ADO`.)

**Auto-detect base branch** for each repo:
```powershell
git -C <path> symbolic-ref refs/remotes/origin/HEAD 2>$null
# Falls back to checking git branch -r for origin/main or origin/dev
```

#### Step 3b: Discover Modules

For each repo, discover the logical modules inside it. Detection is language-agnostic —
look for common project structure signals:

| Signal | What it means |
|--------|---------------|
| `settings.gradle` / `build.gradle` with `include` | Android/JVM multi-module (Gradle) |
| `pom.xml` with `<modules>` | Java multi-module (Maven) |
| `package.json` in subdirectories / `workspaces` field | Node.js/JS monorepo |
| `go.work` or multiple `go.mod` files | Go multi-module workspace |
| `Cargo.toml` with `[workspace]` members | Rust workspace |
| `*.csproj` / `*.sln` with multiple projects | .NET solution |
| `pyproject.toml` / `setup.py` in subdirectories | Python multi-package |
| Directories with their own `src/` or `lib/` | Generic convention |
| Single `src/` at root, no sub-projects | Single-module repo |

If a repo has only one module, the module name defaults to the repo name.
If a repo has multiple modules, list each with its path relative to the repo root.

#### Step 3c: Confirm Mapping

Present the auto-detected results in a **readable list format** (tables get squeezed in chat
when columns have long content — use a list instead):

```markdown
## Detected Repositories & Modules

### 1. org/common-repo
- **Host**: GitHub | **Branch**: dev
- **Modules**: core, api, shared-utils

### 2. org/service-repo
- **Host**: ADO | **Branch**: main
- **Modules**: service, worker

### 3. org/client-repo
- **Host**: GitHub | **Branch**: dev
- **Modules**: client
```

If a repo has many modules (>10), group or summarize them:
> "**Modules** (25 detected): app, CoreLibrary, SharedUtils, ... and 22 more.
> See full list below."

Then use the `get_confirmation` tool to confirm:

```
get_confirmation({
  message: "Does this repository and module mapping look correct?",
  confirmLabel: "Looks good",
  denyLabel: "I need to make corrections"
})
```

If denied, ask what to change (add/remove repos, fix slugs, rename modules, etc.),
rebuild the list, and call `get_confirmation` again. Repeat until confirmed.

The config stores repos and modules separately:
```json
"repositories": {
  "common-repo": { "slug": "org/common-repo", "host": "github", "baseBranch": "dev" },
  "service-repo": { "slug": "org/project/service-repo", "host": "ado", "baseBranch": "main" }
},
"modules": {
  "core": { "repo": "common-repo", "path": "core/", "purpose": "Shared utilities" },
  "api": { "repo": "common-repo", "path": "api/", "purpose": "Public API surface" },
  "service": { "repo": "service-repo", "purpose": "Backend processing" }
}
```

Work items reference a **module name** → lookup `modules.<name>.repo` → lookup `repositories.<repo>` for slug, branch, and account type.

---

### Step 4: Discover & Configure Accounts

Tell the user:
> "Now I'll check your authentication. The orchestrator needs to know which accounts
> to use when dispatching work to each repo and creating work items."

**Check which discovery sub-steps are needed** based on repos from Step 3:
- If ALL repos are on ADO (Azure DevOps) → **skip GitHub account discovery entirely**
- If ALL repos are on GitHub → **skip ADO account discovery entirely**
- If repos are mixed → do both

#### GitHub Account Discovery (skip if no GitHub repos)

**If `gh` CLI is not installed**, skip this section. Tell the user:
> "Skipping GitHub account setup — `gh` CLI is not installed. Install it later to enable dispatch."

**If `gh` is installed**, first determine how many accounts are likely needed by analyzing
the GitHub repos from Step 3:

1. **Collect the distinct GitHub orgs** from all GitHub repo slugs (e.g., `AzureAD`, `identity-authnz-teams`)
2. **Estimate minimum accounts needed**:
   - If all repos belong to the **same org** → likely 1 account
   - If repos span **multiple orgs** → different orgs often mean different accounts
     (a user cannot use a public GitHub account to dispatch to an enterprise-managed org)

Now discover logged-in accounts:
```powershell
$ghStatus = gh auth status 2>&1
```

Parse the output to find every logged-in account.

**If accounts are found**, present them and proceed to mapping.

**If NO accounts are found**, guide the user through login based on what we know:

- **If all repos are in the same org** (likely 1 account needed):
  > "You're not signed in to GitHub CLI. Let's sign in with the account that has
  > access to `<org>/*` repos."
  Guide: `gh auth login --hostname github.com --git-protocol https --web`

- **If repos span multiple orgs** (likely multiple accounts needed):
  > "You're not signed in to GitHub CLI. Your repos span multiple GitHub organizations
  > (`<org1>`, `<org2>`), so you'll likely need separate accounts for each.
  > Let's start with the account for `<org1>/*` repos."
  Guide: `gh auth login --hostname github.com --git-protocol https --web`
  After first login, ask:
  ```
  askQuestion({
    question: "Do you need a different account for <org2>/* repos?",
    options: [
      { label: "Yes, sign in with another account", description: "I use a separate account for <org2>" },
      { label: "No, same account", description: "My <logged-in-user> account has access to all orgs" }
    ]
  })
  ```
  If yes, guide another `gh auth login` flow.

After all logins, re-run `gh auth status` and present ALL discovered accounts:
```markdown
## GitHub Accounts Found
1. `johndoe` (github.com)
2. `johndoe_microsoft` (github.com)
```

#### Map GitHub Accounts to Repositories

Tell the user:
> "Each GitHub repository needs to be assigned to a specific account. The orchestrator
> uses `gh auth switch --user <username>` before running commands against that repo."

**If only ONE GitHub account** is discovered and there are GitHub repos:
Set all GitHub repos to use that account automatically. Confirm with `get_confirmation`:
```
get_confirmation({
  message: "Only one GitHub account found (<username>). Use it for all GitHub repos?",
  confirmLabel: "Yes",
  denyLabel: "No, I need to add another account"
})
```
If denied, guide `gh auth login` for the additional account, then proceed to per-repo mapping.

**If MULTIPLE GitHub accounts** are discovered, ask per-repo which account to use.
**IMPORTANT**: Include the repo slug clearly in each question's `header` field so the user
knows exactly which repo they're assigning an account to:

```
askQuestion({
  questions: [
    // One question per GitHub repo from Step 3:
    {
      header: "Account for: microsoft/VerifiableCredential-SDK-Android",
      question: "Which GitHub account should be used for microsoft/VerifiableCredential-SDK-Android?",
      options: [
        // List ALL discovered accounts as options:
        { label: "johndoe", description: "github.com" },
        { label: "johndoe_microsoft", description: "github.com (EMU)" }
      ]
    },
    {
      header: "Account for: microsoft/entra-verifiedid-wallet-library-android",
      question: "Which GitHub account should be used for microsoft/entra-verifiedid-wallet-library-android?",
      options: [
        { label: "johndoe", description: "github.com" },
        { label: "johndoe_microsoft", description: "github.com (EMU)" }
      ]
    }
    // ... repeat for each GitHub repo
  ]
})
```

Save the account mapping to **`developer-local.json` ONLY** (per-developer, gitignored):
```json
{
  "github_accounts": {
    "org/common-repo": "johndoe",
    "org/service-repo": "johndoe_microsoft",
    "other-org/client-repo": "johndoe-alt"
  }
}
```

**⚠️ NEVER put GitHub usernames in `orchestrator-config.json`** — that file is committed
and shared with the entire team. Usernames are personal and belong only in
`developer-local.json` (which is gitignored). The shared config should only contain:
```json
"github": {
  "configFile": ".github/developer-local.json"
}
```

Tell the user to add `.github/developer-local.json` to `.gitignore` if not already there.

#### Azure DevOps Account Discovery (skip if no ADO config)

**Skip if** there are no ADO-hosted repos AND no ADO work item configuration needed.

Tell the user:
> "Checking Azure CLI authentication. This enables the ADO MCP Server to create work items
> and query iterations."

Check if Azure CLI is available and authenticated:
```powershell
az --version
az account show --only-show-errors -o none 2>&1
```

If `az` is installed:
1. Check if the `azure-devops` extension is installed:
   ```powershell
   az extension list -o json | ConvertFrom-Json | Where-Object { $_.name -eq "azure-devops" }
   ```
   If missing, install it: `az extension add --name azure-devops`

2. Check authentication:
   ```powershell
   az account show -o json
   ```
   If not authenticated, guide: `az login`

3. Set the default org/project (using ADO hints from Pre-Discovery):
   ```powershell
   az devops configure --defaults organization=https://dev.azure.com/<org> project=<project>
   ```

If `az` is not installed:
> "Azure CLI is optional but recommended for live PBI status updates.
> Install: `winget install Microsoft.AzureCLI` (Windows) or `brew install azure-cli` (macOS)"

---

### Step 5: Azure DevOps Work Item Configuration

Tell the user:
> "The orchestrator creates work items (PBIs/User Stories) in Azure DevOps to track
> implementation progress. This step configures which ADO project to use for **work items**
> (your backlog/board). This may be different from the ADO project that hosts your repos."

**Auto-detect from repo URLs**: If any ADO-hosted repos were discovered in Pre-Discovery,
parse the org and project from their URL as a starting suggestion.

**Important**: The ADO project for **work items** (boards, sprints) may differ from the
project that hosts the **repo**. Always let the user override.

```
askQuestion({
  questions: [
    {
      header: "ADO Organization",
      question: "Azure DevOps organization for work items:",
      options: [
        { label: "<detected-org>", description: "Detected from your ADO repo URL", recommended: true }
      ],
      allowFreeformInput: true
    },
    {
      header: "ADO Project (for work items / board)",
      question: "Which ADO project holds your backlog and sprints? (This may differ from your repo project)",
      options: [
        { label: "<detected-project>", description: "Detected from repo URL — confirm this is where your PBIs live", recommended: true }
      ],
      allowFreeformInput: true
    },
    {
      header: "Work Item Type",
      question: "Default work item type:",
      options: [
        { label: "Product Backlog Item", recommended: true },
        { label: "User Story" },
        { label: "Task" }
      ],
      allowFreeformInput: true
    }
  ]
})
```

---

### Step 6: Design Docs

Tell the user:
> "Before coding, the orchestrator writes a design spec for team review. I need to know
> where to save these specs. If your team has a design doc template, I'll follow it —
> otherwise I'll use a built-in template covering problem, solution options, and trade-offs."

```
askQuestion({
  questions: [
    {
      header: "Design Docs Path",
      question: "Where should design specs be saved?",
      options: [
        { label: "docs/designs/", description: "Standard docs folder" },
        { label: "design-docs/", description: "Dedicated design docs folder" }
      ],
      allowFreeformInput: true
    },
    {
      header: "Design Template",
      question: "Do you have a design spec template?",
      options: [
        { label: "No template", description: "Use the built-in template", recommended: true },
        { label: "Custom template", description: "I'll provide a path" }
      ],
      allowFreeformInput: true
    }
  ]
})
```

---

### Step 7: Codebase Knowledge (optional)

Tell the user:
> "Optionally, you can provide extra context about your codebase that helps the AI
> research more effectively — like a high-level architecture description or common
> search patterns. This is optional and can be added later by editing the config file."

Ask if they want to add:
- Module descriptions for the researcher
- Architecture overview
- Common search patterns

---

### Step 8: Finalize — Write Config & Install State CLI

Tell the user:
> "Great — I have everything I need. Let me write the configuration and set up the
> state tracking."

#### Write Config

Save `.github/orchestrator-config.json`:

```json
{
  "project": {
    "name": "<name>",
    "description": "<description>"
  },
  "repositories": {
    "<repo-key>": {
      "slug": "<org/repo>",
      "host": "github",
      "baseBranch": "dev"
    }
  },
  "modules": {
    "<module-name>": {
      "repo": "<repo-key>",
      "path": "<path-within-repo>/",
      "purpose": "<brief description>"
    }
  },
  "github": {
    "configFile": ".github/developer-local.json"
  },
  "ado": {
    "org": "<org>",
    "project": "<project>",
    "workItemType": "Product Backlog Item",
    "iterationDepth": 6
  },
  "design": {
    "docsPath": "<path>",
    "templatePath": null,
    "folderPattern": "[{platform}] {featureName}",
    "reviewRepo": null
  },
  "codebase": {
    "architecture": "",
    "searchPatterns": {}
  }
}
```

> "This file should be committed to your repo so your whole team shares the same settings."

#### Install State CLI

Tell the user:
> "Installing the state tracking script to `~/.feature-orchestrator/`. This keeps track
> of which features are in progress, their current pipeline stage, and associated work items
> and PRs. It's shared across all your projects."

Copy `state-utils.js` to the fixed global location `~/.feature-orchestrator/`:
```powershell
$stateDir = Join-Path $HOME ".feature-orchestrator"
if (-not (Test-Path $stateDir)) { New-Item -ItemType Directory -Path $stateDir -Force | Out-Null }

# Find state-utils.js from the plugin installation
# It's in the same repo as this setup command, at hooks/state-utils.js
$pluginStateUtils = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "hooks" "state-utils.js"
if (Test-Path $pluginStateUtils) {
    Copy-Item $pluginStateUtils (Join-Path $stateDir "state-utils.js") -Force
} else {
    # Fallback: create it by reading from the plugin's known location
    Write-Host "Please manually copy state-utils.js to $stateDir"
}
```

**Important**: If the above doesn't find the file automatically, the agent should:
1. Read the `state-utils.js` content from the plugin's `hooks/state-utils.js`
2. Write it to `~/.feature-orchestrator/state-utils.js`

Verify it works:
```powershell
node (Join-Path $HOME ".feature-orchestrator" "state-utils.js") get
```

---

### Done!

**Always end with this exact summary format** — it gives the user a clear overview of
everything that was configured:

```markdown
## ✅ Feature Orchestrator Configured!

**Config saved**: `.github/orchestrator-config.json`
**State directory**: `~/.feature-orchestrator/`
**Developer config**: `.github/developer-local.json` (add to `.gitignore`)

### Detected Setup

| Component | Status |
|-----------|--------|
| **Repos** | N repos (X ADO, Y GitHub) |
| **Modules** | N modules mapped |
| **ADO** | <org> / <project> (PBI) |
| **Design docs** | <docsPath>/ |
| **Node.js** | vX.Y.Z ✅ |
| **GitHub CLI** | vX.Y.Z ✅ (N accounts: user1, user2) |
| **Azure CLI** | vX.Y.Z ✅ (user@domain) |
| **State CLI** | Working ✅ (N features tracked) |

For any component that is missing or not configured, show ⚠️ or ❌ with guidance:
- Not installed: `❌ Not installed — run: <install command>`
- Not authenticated: `⚠️ Not authenticated — run: <auth command>`
- Not applicable: `— (not needed)` (e.g., GitHub CLI when all repos are ADO)

### Available Commands

| Command | Description |
|---------|-------------|
| `feature-design` | Start a new feature with design |
| `feature-plan` | Decompose design into work items |
| `feature-backlog` | Create work items in ADO |
| `feature-dispatch` | Send to Copilot coding agent |
| `feature-status` | Check PR status |
| `feature-continue` | Resume a feature |
| `feature-pr-iterate` | Review and iterate on PRs |

### Quick Start

Describe a feature to get started:
> "I want to add retry logic with exponential backoff to the API client"

Or use `/feature-orchestrator-plugin:feature-design` followed by your feature description.
```
